
<?php 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once "baseController.php";
class  SiteController extends BaseController
{
	public function actionIndex()
	 {
	 	$this->render('site/index');
	 }
	 public function actionAbout()
	 {
	 	$this->render('site/about');
	 }
	  public function actionTeam()
	 {
	 	$this->render('site/team');
	 }
	   public function actionWork()
	 {
	 	$this->render('site/work');
	 }
	  public function actionContact()
	 {
	 	$model = new Contact(); 


	 	if(isset($_POST['send'])){

	 	$model->name=$_POST['name'];
	 	$model->email=$_POST['email'];
	 	$model->subject=$_POST['subject'];
	 	$model->message=$_POST['message'];

	 	if($model->save()){

	 	$this->render('site/index');
	 	}
	 	}

	 	$this->render('site/contact');



	 }
	  public function actionDigitalmarketing()
	 {
	 	$this->render('site/digitalmarketing');
	 }

	  public function actionPrintmedia()
	 {
	 	$this->render('site/printmedia');
	 }
	  public function actionBranding()
	 {
	 	$this->render('site/branding');
	 }
	 
}
?>