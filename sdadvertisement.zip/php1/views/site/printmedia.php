<div class="container">
		<div class="col-md-12"><h2 class="text-center form-group">Print Media </h2></div>
	<div class="w3-container cntnrinfo">
			<h3 class="text-center mrgbtm ">Brochure Design & Printing</h3>
		<div class="col-md-5 mrglft">
			<img src="assets/images/123.jpg" class="w3-border w3-padding" height="100%" width="100%" alt="Norway">
		</div>

		<div class="col-md-5 col-md-offset-1">
			<h4 class="w3-medium">
				We provide attractive designs for brochure and also printing services. A brochure is an informative paper document (often also used for advertising), that can be folded into a template, pamphlet or leaflet. Brochures are promotional documents, primarily used to introduce a company, organization,products or services and inform prospective customers or members of the public of the benefits.
				Brochures are distributed inside newspapers, handed out personally or placed in brochure racks in high traffic locations. They may be considered as gray literature. 
			</h4>
		</div>
	</div>	
	<div class="w3-container">
	<h3 class="text-center mrgbtm">Flyer Design & Printing</h3>
		<div class="col-md-5 mrglft">
			<h4 class="w3-medium">
			    Get your message out with flyers in a new range of sizes.The purpose of a flyer is to offer a small amount of information for a limited time at low manufacturing costs. A flyer is one piece of paper, usually the standard size of 8 ½” x 11″ (A4). Flyers are best for small scale marketing, or when you have a small region to cover. Flyers are a cheap way to get info out to a large number of people.
			</h4>
		</div>
		<div class="col-md-5 col-md-offset-1">
			<img src="assets/images/123.jpg" class="w3-border w3-padding" height="100%" width="100%" alt="Norway">
		</div>
	</div>	
	<div class="w3-container">
			<h3 class="text-center mrgbtm">Poster Design & Printing</h3>
		<div class="col-md-5 mrglft">
			<img src="assets/images/123.jpg" class="w3-border w3-padding" height="100%" width="100%" alt="Norway">
		</div>

		<div class="col-md-5 col-md-offset-1">
			<h4 class="w3-medium">
			We provide attractive designs for poster and also printing services.A poster is any piece of printed paper designed to be attached to a wall or vertical surface. Typically posters include both textual and graphic elements, although a poster may be either wholly graphical or wholly text. Posters are designed to be both eye-catching and informative.Posters are also used for reproductions of artwork, particularly famous works, and are generally low-cost compared to original artwork. 
			</h4>
		</div>
	</div>	
	
</div>