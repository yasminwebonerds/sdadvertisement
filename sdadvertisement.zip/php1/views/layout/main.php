<!DOCTYPE html>
<html>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/custom.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<body>
<div>
<!-- Navbar (sit on top) -->
<div class="w3-top">
  <ul class="w3-navbar w3-white w3-card-2" id="myNavbar">
    <li>
      <a href="<?php echo HTML::url('site/index'); ?>" class="w3-wide logoname">
       Smart & Digital Avertisements 
      </a>
    </li>
    <!-- Right-sided navbar links -->
    <li class="w3-right w3-hide-small">
    <a href="<?php echo HTML::url('site/index'); ?>"><b>Home</b></a>
      <a href="<?php echo HTML::url('site/about'); ?>"><b>About</b></a>
      <a href="<?php echo HTML::url('site/team'); ?>"><i class="fa fa-user"></i> <b>Team</b></a>
    <!--   <a href="<?php// echo HTML::url('site/work'); ?>"><i class="fa fa-th"></i> Work</a> -->
      <a href="<?php echo HTML::url('site/contact'); ?>"><i class="fa fa-envelope"></i> <b>Contact</b></a>
    </li>
    <!-- Hide right-floated links on small screens and replace them with a menu icon -->
    <li>
      <a href="javascript:void(0)" class="w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
        <i class="fa fa-bars w3-padding-right w3-padding-left"></i>
      </a>
    </li>
  </ul>
</div>

<!-- Sidenav on small screens when clicking the menu icon -->
<nav class="w3-sidenav w3-black w3-card-2 w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidenav">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-large w3-padding-16">Close ×</a>
   <a href="#about" onclick="w3_close()">Home</a>
  <a href="#about" onclick="w3_close()">About</a>
  <a href="#team" onclick="w3_close()">Team</a>
 <!--  <a href="#work" onclick="w3_close()">Work</a> -->
  <a href="#contact" onclick="w3_close()">Contact</a>
</nav>
</div>


<div class="" style="margin-top:45px;">






 

