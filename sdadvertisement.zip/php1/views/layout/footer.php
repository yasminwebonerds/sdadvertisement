
 
</div>
<!-- 
<footer class="w3-center w3-black w3-padding-64">
  
  <div class="w3-xlarge w3-section">
    <i class="fa fa-facebook-official w3-hover-text-indigo"></i>
    <i class="fa fa-flickr w3-hover-text-red"></i>
    <i class="fa fa-instagram w3-hover-text-purple"></i>
    <i class="fa fa-twitter w3-hover-text-light-blue"></i>
    <i class="fa fa-linkedin w3-hover-text-indigo"></i>
  </div>
 <a href="<?php //echo HTML::url('site/index');?>" class="w3-btn pull-right"><i class="fa fa-chevron-up fa-2x"></i></a>
</footer> -->
<footer>
	<div class="footer_in">
    	<div class="adrs">
        	<div class="get_in">
            	Get in Touch
            </div>
						<div class="add">Office No.6,Yashlakshmi Phase 1, Khodad Road, Narayangaon.</div>	
			<div class="adres">
			Mobile : <span style="font-weight:normal">+91-9552892451 ,&nbsp;9552892451</span>
			</div>
			<div class="mail_id">
			E-mail : <span><a href="mailto:info@webingeer.com">info@webingeer.com</a></span>
			</div>
        </div>
        <div class="usefull">
        	<div class="get_in">
            	Useful Links
            </div>
            <ul>
            	<li><a href="index.php" title="Home">Home</a></li>
                <li><a href="web-development-company-india-about-us.php" title="About">About</a></li>
                
                <li><a href="contact-us.php" title="Contact Us">Contact Us</a></li>
            </ul>	
        </div>
        <div class="usefull">
        	<div class="get_in">
            	Our Service Offered
            </div>
            <ul>
				<li><a href="web-development-company-india.php" title="Website Development">Website Development</a></li>
				<li><a href="web-design-company-india.php" title="Website Designing">Website Designing</a></li>
				<li><a href="e-commerce-web-solution-company.php" title="Ecommerce Solutions">Ecommerce Solutions</a></li>
				<li><a href="psd-to-html.php" title="PSD to Html Conversion">PSD to Html Conversion</a></li>
				<li><a href="mobile-responsive-websites.php" title="Mobile Responsive">Mobile Responsive</a></li>
				<li><a href="iPhone-app-development-india.php" title="Iphone Application">Iphone Application</a></li>
				<li><a href="services.php" title="Read All">Read All</a></li>
            </ul>	
        </div>
        <div class="clear123"></div>
        <div class="social">
        	<div class="get_in" id="get_in">
            	Social Media
            </div>
            <div class="icon">
            	<a href="https://www.facebook.com/" title="facebook" target="_blank"><img src="images/fb.png" alt="Facebook" title="Facebook" width="30" height="30"></a> 
                <a href="https://www.facebook.com/" title="facebook" target="_blank"><span>Facebook</span></a>                
            </div>
            	<div class="clear"></div>
            <div class="icon">
            	<a href="https://twitter.com/" title="Twitter" target="_blank"><img src="images/twit.png" alt="Twitter" title="Twitter" width="30" height="30"></a> 
                <a href="https://twitter.com/" title="Twitter" target="_blank"><span>Twitter</span></a>
            </div>
            	<div class="clear"></div>
            <div class="icon">
            	<a href="https://www.linkedin.com/" title="Linkedin" target="_blank"><img src="images/in.png" alt="Linkedin" title="Linkedin" width="30" height="30"></a> 
                <a href="https://www.linkedin.com/" title="Linkedin" target="_blank"><span>Linkedin</span></a>
            </div>
            	<div class="clear"></div>
            <div class="icon">
            	<a href="https://plus.google.com/" title="Google Plus" target="_blank"><img src="images/g%2b.png" alt="Google+" title="Google Plus" width="30" height="30"></a> 
                <a href="https://plus.google.com/" title="Google Plus" target="_blank"><span>Google Plus</span></a>
            </div>
            	<div class="clear"></div>
			<div class="icon">
            	<a href="https://www.youtube.com/" title="YouTube" target="_blank"><img src="images/youtube-icon-black.png" alt="YouTube" title="YouTube" width="30" height="30"></a> 
                <a href="https://www.youtube.com/" title="YouTube" target="_blank"><span>YouTube</span></a>
            </div>
        </div>
        
        <!--For mobile-->
        <div class="social1">
        <div class="get_in">
            Social Media
        </div>
        <ul>
            <li>
            <a href="https://www.facebook.com/" title="facebook" target="_blank"><img src="images/fb.png" alt="Facebook" title="Facebook" width="30" height="30"></a></li>
            <li><a href="https://twitter.com/" title="Twitter"><img src="images/twit.png" alt="Twitter" title="Twitter" width="30" height="30"></a></li>
            <li><a href="https://www.linkedin.com/" title="Linkedin"><img src="images/in.png" alt="Linkedin" title="Linkedin" width="30" height="30"></a></li>
            <li><a href="https://plus.google.com/" title="Google Plus"><img src="images/g%2b.png" alt="Google+" title="Google Plus" width="30" height="30"></a></li>
        </ul>
        </div>
        <!--For mobile-->
        <div class="clear"></div>
    </div>
</footer>
<div class="footer">
	All rights reserved by <a href="index.php" title="" target="_blank">webingeer.com</a> 
</div>
</body>
</html>
